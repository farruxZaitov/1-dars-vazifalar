/*INSERT INTO lavozim(lavozim_enum_nomi)
values ('ADMIN'),
       ('SUPERUSER'),
       ('USER')*/