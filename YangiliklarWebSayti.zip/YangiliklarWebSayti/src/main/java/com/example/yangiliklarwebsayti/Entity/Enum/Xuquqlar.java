package com.example.yangiliklarwebsayti.Entity.Enum;

public enum Xuquqlar {
    ADDUSER,
    DALETEUSER,
    EDITUSER,
    REDUSER,        //Foydalanuvchilar user uqish

    ADDPOST,
    EDITPOST,
    DALETEPOST,
    REDPOST,

    ADDKOMENT,
    DALETEKOMENT,
    EDITKOMENT,
    REDKOMENT,

    DELETEMYKOMENT,
    EDITMAYCOMENT,

    ADDLOVOZIM,
    RIDLOVOZIM,
    DELETELAVOZIM,
    EDITLOVOZIM;


}
