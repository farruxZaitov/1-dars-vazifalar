package com.example.yangiliklarwebsayti.Dto;

import com.example.yangiliklarwebsayti.Entity.Post;
import lombok.Data;

@Data
public class KamantaryDto {
    private String matn;
    private Post postid;
}
