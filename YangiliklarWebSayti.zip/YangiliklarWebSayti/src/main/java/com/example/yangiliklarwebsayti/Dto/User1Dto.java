package com.example.yangiliklarwebsayti.Dto;

import lombok.Data;

@Data
public class User1Dto {
    private String ismi;
    private String familyasi;
    private String username;
    private String lavozim;
    private String password;
    private String repassword;
}
