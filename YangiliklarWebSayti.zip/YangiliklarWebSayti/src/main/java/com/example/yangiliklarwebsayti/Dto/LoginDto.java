package com.example.yangiliklarwebsayti.Dto;

import lombok.Data;

@Data
public class LoginDto {
    private String username;
    private String password;
}
