package com.example.yangiliklarwebsayti.Dto;

import lombok.Data;

@Data
public class PostDto {
    private String titile;
    private String text;
}
