package com.example.yangiliklarwebsayti.Entity.Apstrakt;

public interface LavozimConsdata {
    String ADMIN="admin";
    String USER="user";


}
