package com.example.yangiliklarwebsayti.Dto;

import lombok.Data;

@Data
public class UserDto {
    private String ismi;
    private String familyasi;
    private String username;
    private String password;
    private String repassword;

}
