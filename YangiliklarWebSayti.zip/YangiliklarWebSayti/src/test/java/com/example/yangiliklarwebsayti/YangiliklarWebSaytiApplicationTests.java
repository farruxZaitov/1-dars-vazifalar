package com.example.yangiliklarwebsayti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YangiliklarWebSaytiApplicationTests {

    @Test
    void contextLoads() {
    }

}
