package com.example.web_toke1.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class API_Respons {
    private String Habar;
    private boolean Xolat;
}
