package com.example.web_toke1.DTO;

import lombok.Data;

@Data
public class User_Dto {
    private String username;
    private String password;

}
