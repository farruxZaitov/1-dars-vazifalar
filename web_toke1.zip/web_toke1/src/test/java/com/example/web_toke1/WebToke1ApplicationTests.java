package com.example.web_toke1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebToke1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
