package com.example.maxsusanatatsiyalar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaxsusAnatatsiyalarApplicationTests {

    @Test
    void contextLoads() {
    }

}
