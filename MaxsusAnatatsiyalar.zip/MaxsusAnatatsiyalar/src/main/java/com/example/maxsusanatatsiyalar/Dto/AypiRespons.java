package com.example.maxsusanatatsiyalar.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AypiRespons {
    private String Xabar;
    private boolean Holat;
}
