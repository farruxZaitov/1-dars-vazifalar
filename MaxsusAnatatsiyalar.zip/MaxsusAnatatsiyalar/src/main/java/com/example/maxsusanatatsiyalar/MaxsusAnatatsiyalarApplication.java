package com.example.maxsusanatatsiyalar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaxsusAnatatsiyalarApplication {

    public static void main(String[] args) {
        SpringApplication.run(MaxsusAnatatsiyalarApplication.class, args);
    }

}
