package com.example.maxsusanatatsiyalar.Secuerity;

import com.example.maxsusanatatsiyalar.Servis.MijozServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;


@Configuration
public class Settings {

}
