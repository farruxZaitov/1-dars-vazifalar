package com.example.maxsusanatatsiyalar.Dto;

import lombok.Data;

@Data
public class ManzilDto {
    private String viloyat;
    private String tuman;
    private String kocha;
    private String fish;
    private String telNomer;
}
