package com.example.firmawebsayti.Entity;

import com.example.firmawebsayti.Entity.Abstrak.Abstrakt;
import com.example.firmawebsayti.Entity.Enum.Xuquqlar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class BulimEntity extends Abstrakt {
    private String nomi;





}
