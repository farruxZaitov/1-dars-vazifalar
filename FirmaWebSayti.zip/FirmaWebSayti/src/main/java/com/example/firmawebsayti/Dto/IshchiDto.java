package com.example.firmawebsayti.Dto;

import lombok.Data;

@Data
public class IshchiDto {

    private String ismi;
    private String familyasi;
    private String username;
    private String password;
    private String repassword;
    private Integer bulimId;
}
