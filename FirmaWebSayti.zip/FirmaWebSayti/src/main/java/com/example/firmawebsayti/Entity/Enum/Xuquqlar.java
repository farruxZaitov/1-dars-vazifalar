package com.example.firmawebsayti.Entity.Enum;

public enum Xuquqlar {
    ADDDEPART,
    DALETEDEPART,
    EDITDEPART,
    REDDEPART,        //Foydalanuvchilar user uqish

    ADDISH,
    DALETEISH,
    EDITISH,
    REDISH,

    ADDBULIM,
    READBULIM,
    DELETEBULIM,
    EDITBULIM,

    ADDLOVOZIM,
    RIDLOVOZIM,
    DELETELAVOZIM,
    EDITLOVOZIM





}
