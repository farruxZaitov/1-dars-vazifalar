package com.example.firmawebsayti.Entity.Abstrak;

public interface IshchiConsdata {
    String ADMIN="admin";
    String USER="user";
}
