package com.example.firmawebsayti.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AypiRespons {
    private String Xabar;
    private boolean Holat;
}
