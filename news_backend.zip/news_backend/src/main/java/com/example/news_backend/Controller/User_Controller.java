package com.example.news_backend.Controller;

import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.UserDuto1;
import com.example.news_backend.Servise.Servise;
import com.example.news_backend.Servise.User1_Servic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user1")
public class User_Controller {
    @Autowired
    User1_Servic user1_servic;
    @PostMapping("/qoshish")
    public HttpEntity<?> QOshish(@RequestBody UserDuto1 userDuto1){
        ApiResponse apiResponse=user1_servic.qoshish(userDuto1);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @GetMapping("/korish")
    public HttpEntity<?> Korish(){
        ApiResponse apiResponse=user1_servic.korish();
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @GetMapping("/{id}")
    public HttpEntity<?> Idboyicha(@PathVariable Integer id){
        ApiResponse apiResponse=user1_servic.idboyicha(id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @PutMapping("/taxrilash/{id}")
    public HttpEntity<?> Taxrilash(@PathVariable Integer id,@RequestBody UserDuto1 userDuto1){
        ApiResponse apiResponse=user1_servic.taxrilash(userDuto1,id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @DeleteMapping("/{id}")
    public HttpEntity<?> Delet(@PathVariable Integer id){
        ApiResponse apiResponse=user1_servic.delet(id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
}
