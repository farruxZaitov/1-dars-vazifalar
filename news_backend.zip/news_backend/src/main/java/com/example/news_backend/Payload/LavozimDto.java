package com.example.news_backend.Payload;

import com.example.news_backend.Entity.Enum.Huquqlar;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.FetchType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class LavozimDto {
    @NotBlank(message = "Lavozim nomida probel ishlatish mumkin emas")
    private String nomi;

    //@NotNull(message = "huquqlar listi bo'sh bo'lmasligi kerak !")
    @NotEmpty(message = "huquqlar listi bo'sh bo'lmasligi kerak !")
    @ElementCollection(fetch = FetchType.LAZY)
    private List<Huquqlar> huquqlarList;

    @NotNull(message = "izoh bosh bolmasligi kerak")
    private String izoh;
}
