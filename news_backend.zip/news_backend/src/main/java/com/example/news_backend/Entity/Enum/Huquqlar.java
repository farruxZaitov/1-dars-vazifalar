package com.example.news_backend.Entity.Enum;

public enum Huquqlar {
    ADD_USER,
    UPDATE_USER,
    DELETE_USER,
    READ_USER,

    ADD_POST,
    EDIT_POST,
    DELETE_POST,
    READ_POST,

    ADD_COMMENT,
    EDIT_COMMENT,
    READ_COMMENT,
    DELETE_COMMENT,
    DELETE_MY_COMMENT,
    EDIT_MY_COMMENT,

    ADD_ROLE,
    EDIT_ROLE,
    DELETE_ROLE,
    READ_ROLE,

}
