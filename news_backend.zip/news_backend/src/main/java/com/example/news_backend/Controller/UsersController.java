package com.example.news_backend.Controller;


import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.LoginDto;
import com.example.news_backend.Payload.UsersDto;
import com.example.news_backend.Servise.Servise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UsersController {
    @Autowired
    Servise servise;

    @PostMapping("/add")
    public HttpEntity<?> Add(@RequestBody UsersDto usersDto){
        ApiResponse apiResponse =  servise.add(usersDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @GetMapping("/emailtasdiqlash")
    public HttpEntity<?> Tasdiqlash(@RequestParam String useremail, @RequestParam String emailkod){
        ApiResponse apiResponse = servise.faollashtirish(useremail,emailkod);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }

    @PostMapping("/login")
    public HttpEntity<?> Login(@RequestBody LoginDto loginDto){
        ApiResponse apiResponse = servise.login(loginDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
}
