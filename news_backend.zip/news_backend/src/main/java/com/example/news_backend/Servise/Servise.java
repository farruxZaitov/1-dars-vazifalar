package com.example.news_backend.Servise;

import com.example.news_backend.Entity.Abstrak.LavozimConstanta;
import com.example.news_backend.Entity.Lavozim;
import com.example.news_backend.Entity.Users;
import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.LoginDto;
import com.example.news_backend.Payload.UsersDto;
import com.example.news_backend.Repository.LavozimRepository;
import com.example.news_backend.Repository.UsersRepository;
import com.example.news_backend.Token.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.tools.JavaFileManager;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class Servise  implements UserDetailsService {
    @Autowired
    UsersRepository usersRepository;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    LavozimRepository lavozimRepository;
    @Autowired
    Token token;
    @Autowired
    JavaMailSender getjavaMailSender;

    @Autowired
    AuthenticationManager authenticationManager;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Users> byUsername = usersRepository.findByUsername(username);
        if (byUsername.isPresent()){
            return byUsername.get();
        }
        return (UserDetails) new UsernameNotFoundException("username topilmadi");
    }


    public ApiResponse add(UsersDto usersDto) {
        boolean b = usersRepository.existsByUsername(usersDto.getUsername());
        if (b) {
            return new ApiResponse("Bunday username bor",false);
        }
        if(usersDto.getPassword().equals(usersDto.getRepassword())){
            Users users = new Users();
            users.setFirsname(usersDto.getFirsname());
            users.setLastname(usersDto.getLastname());
            users.setNumber(usersDto.getNumber());
            users.setUsername(usersDto.getUsername());
            users.setPassword(passwordEncoder.encode(usersDto.getPassword()));
            users.setEmailKod(UUID.randomUUID().toString().substring(0,6));
            users.setLavozim(lavozimRepository.findByNomi(LavozimConstanta.USER).get());
            /*Lavozim lavozim = new Lavozim();
            lavozim.setNomi(LavozimConstanta.USER);
            users.setLavozim(lavozim);
            lavozimRepository.save(lavozim);*/
            boolean xabaryuborish = Xabaryuborish(users.getUsername(), users.getEmailKod());
            if(xabaryuborish){
                users.setEnabled(true);
                usersRepository.save(users);
                return new ApiResponse("hisobni faollashtirish kodi email hisobingizga yuborildi", true);
            }
        }
        return new ApiResponse("Ro'yxatdan o'tmadiz, malumotlaringizni tekshirib qayta kiritinng!",false);
    }
    public boolean Xabaryuborish(String email,String emailkod){
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom("asadbekrustamov575@gmail.com");
            mailMessage.setTo(email);
            mailMessage.setSubject("Confirmation email");
            mailMessage.setText("<a href='http://localhost:8080/users/emailtasdiqlash?useremail="+email+"&emailkod="+emailkod+"'>hisobni tasdiqlash</a>");
            getjavaMailSender.send(mailMessage);
            return true;
        }
        catch (Exception e){
            e.getStackTrace();
        }
        return false;
    }




    public ApiResponse login(LoginDto loginDto) {
        try {
            Optional<Users> byUsername = usersRepository.findByUsername(loginDto.getUsername());
            if (byUsername.isPresent()){
                Users users = byUsername.get();
                if (users.getEmailKod()==null){
                    Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));
                    Users principal = (Users) authenticate.getPrincipal();
                    String s = token.CreateToken(principal.getUsername(), principal.getLavozim());
                    return new ApiResponse("profilga xush kelibsiz!" + s,true);
                }
                return new ApiResponse("Siz accountgiz foalashtirnig!" ,false);
            }
            return new ApiResponse("Email xato!" ,false);
        }
        catch (Exception e) {
            return new ApiResponse("login yoki parol xato", false);
        }
        //return new ApiResponse("Xato",false);
    }

    public ApiResponse faollashtirish(String useremail, String emailkod) {
        Optional<Users> byUsernameAndEmailKod = usersRepository.findByUsernameAndEmailKod(useremail, emailkod);
        if(byUsernameAndEmailKod.isPresent()){
            Users users = byUsernameAndEmailKod.get();
            users.setEnabled(true);
            users.setEmailKod(null);
            usersRepository.save(users);
            return new ApiResponse("Hisobingiz faollashtirildi!", true);
        }
        return new ApiResponse("Akkauntingiz allaqachon faolashtirilmadi!",false);
    }
}
