package com.example.news_backend.Payload;

import com.example.news_backend.Entity.Post;
import lombok.Data;

@Data
public class CommmentDto {
    private String comment_text;
    private Post postid;
}
