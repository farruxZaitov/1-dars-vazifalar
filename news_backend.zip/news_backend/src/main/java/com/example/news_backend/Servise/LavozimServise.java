package com.example.news_backend.Servise;

import com.example.news_backend.Entity.Lavozim;
import com.example.news_backend.Entity.Users;
import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.LavozimDto;
import com.example.news_backend.Repository.LavozimRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LavozimServise {
    @Autowired
    LavozimRepository lavozimRepository;

    public ApiResponse AddLavozim(LavozimDto lavozimDto) {
        Optional<Lavozim> byNomi = lavozimRepository.findByNomi(lavozimDto.getNomi());
        if (byNomi.isPresent()){
            return new ApiResponse("Bunday lavozim mavjud",false);
        }
        Lavozim lavozim = new Lavozim();
        lavozim.setNomi(lavozimDto.getNomi());
        lavozim.setIzoh(lavozimDto.getIzoh());
        lavozim.setHuquqlarList(lavozimDto.getHuquqlarList());
        lavozimRepository.save(lavozim);
        return new ApiResponse("Lavozim saqlnadi", true);
    }

    public ApiResponse korish() {
        List<Lavozim> all = lavozimRepository.findAll();
        return new ApiResponse(all.toString(),true);
    }

    public ApiResponse idboyicha(Integer id) {
        Optional<Lavozim> byId = lavozimRepository.findById(id);
        if (byId.isPresent()){
            return new ApiResponse(byId.get().toString(),true);
        }
        return new ApiResponse("Ma'lumotni boshqatan kirtib ko'ring",false);
    }

    public ApiResponse taxrilash(Integer id, LavozimDto lavozimDto) {
        Optional<Lavozim> byId = lavozimRepository.findById(id);
        if (byId.isPresent()){
            Lavozim lavozim=new Lavozim();
            lavozim.setNomi(lavozimDto.getNomi());
            lavozim.setIzoh(lavozimDto.getIzoh());
            lavozim.setHuquqlarList(lavozimDto.getHuquqlarList());
            lavozimRepository.save(lavozim);
            return new ApiResponse("Ma'lumotingiz muvaqiyatli taxrilandi",true);
        }
        return new ApiResponse("Ma'lumotingiz taxrilamdi qaytadan urinib ko'ring ",false);
    }

    public ApiResponse delet(Integer id) {
        try {
            lavozimRepository.deleteById(id);
            return new ApiResponse("Ma'lumot muvaqiyatli o'chirildi",true);
        }
        catch (Exception e){
            return new ApiResponse("O'chirilmadi", false);
        }

    }
}
