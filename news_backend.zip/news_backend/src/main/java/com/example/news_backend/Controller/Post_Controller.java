package com.example.news_backend.Controller;

import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.PostDto;
import com.example.news_backend.Servise.Post_Servis;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/post")
public class Post_Controller {
    @Autowired
    Post_Servis post_servis;

    @PreAuthorize("hasAuthority('ADD_POST')")  //shu huquqli lavozim shu mappingni ishlata oladi
    @PostMapping("/qoshish")
    public HttpEntity<?> Qoshish(@RequestBody PostDto postDto){
        ApiResponse apiResponse=post_servis.qoshish(postDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }

    @PreAuthorize("hasAuthority('READ_POST')")
    @GetMapping("/korish")
    public HttpEntity<?> Korish(){
        ApiResponse apiResponse=post_servis.korish();
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }

    @PreAuthorize("hasAuthority('READ_POST')")
    @GetMapping("/{id}")
    public HttpEntity<?> Idboyich(@PathVariable Integer id){
        ApiResponse apiResponse=post_servis.idboyicha(id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }

    @PreAuthorize("hasAuthority('EDIT_POST')")
    @PutMapping("/taxrilash/{id}")
    public HttpEntity<?> Taxrilash(@RequestBody PostDto postDto,@PathVariable Integer id){
        ApiResponse apiResponse=post_servis.taxrilash(id,postDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
}
