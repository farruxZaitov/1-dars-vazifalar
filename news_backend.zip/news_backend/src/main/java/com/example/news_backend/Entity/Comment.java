package com.example.news_backend.Entity;

import com.example.news_backend.Entity.Abstrak.AbstrakEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
public class Comment extends AbstrakEntity{
    @Column(nullable = false)
    private String comment_text;

    @ManyToOne(fetch = FetchType.LAZY)
    private Post post;
}
