package com.example.news_backend.Entity;

import com.example.news_backend.Entity.Abstrak.AbstrakEntity;
import com.example.news_backend.Entity.Enum.Huquqlar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
//@EntityListeners(AuditingEntityListener.class)
@EqualsAndHashCode(callSuper = true)
public class Users extends AbstrakEntity implements UserDetails {
    @Column(nullable = false)
    private String firsname;

    @Column(nullable = false)
    private  String lastname;

    @Column(nullable = false)
    private String number;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;
    private String emailKod;

    public Users(String firsname, String lastname, String number, String username, String password, Lavozim lavozim, boolean enabled) {
        this.firsname = firsname;
        this.lastname = lastname;
        this.number = number;
        this.username = username;
        this.password = password;
        this.lavozim = lavozim;
        this.enabled = enabled;
    }

    @ManyToOne
    private Lavozim lavozim;

    private boolean accountNonExpired = true;

    private boolean accountNonLocked = true;

    private boolean credentialsNonExpired = true;

    private boolean enabled = false;




    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        List<Huquqlar> huquqlarList = this.lavozim.getHuquqlarList();
        ArrayList<GrantedAuthority> grantedAuthorityArrayList = new ArrayList<>();
        for (Huquqlar huquqlar : huquqlarList) {
            grantedAuthorityArrayList.add(new GrantedAuthority() {
                @Override
                public String getAuthority() {
                    return huquqlar.name();
                }
            });
        }


        return grantedAuthorityArrayList;
    }
}
