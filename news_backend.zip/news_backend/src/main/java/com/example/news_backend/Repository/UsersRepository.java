package com.example.news_backend.Repository;

import com.example.news_backend.Entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsersRepository extends JpaRepository<Users, Integer> {
    boolean existsByUsername(String username);
    Optional<Users> findByUsernameAndEmailKod(String username, String emailKod);

    Optional<Users> findByUsername(String username);
    Optional<Users> findByEmailKod(String emailKod);
}
