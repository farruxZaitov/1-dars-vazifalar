//package com.example.news_backend.Repository;
//
//import com.example.news_backend.Entity.Comment;
//import com.example.news_backend.Entity.Post;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.Optional;
//
//public interface CommentRepository extends JpaRepository<Comment, Integer> {
//    boolean existsByPostid(Post postid);
//    Optional<Comment> findById(Integer id);
//
//}
