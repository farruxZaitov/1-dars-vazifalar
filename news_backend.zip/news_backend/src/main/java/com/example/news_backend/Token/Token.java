package com.example.news_backend.Token;

import com.example.news_backend.Entity.Enum.Huquqlar;
import com.example.news_backend.Entity.Lavozim;
import com.example.news_backend.Entity.Users;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class Token {
    public String key = "qwert";
    public String CreateToken(String username, Lavozim lavozim){
        Long vaqt = Long.valueOf(60*60*100*24);
        Date date = new Date(System.currentTimeMillis()+vaqt);

        String token = Jwts
                .builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(date)
                .claim("lavozim",lavozim.getNomi())
                .signWith(SignatureAlgorithm.HS512, key)
                .compact();
        return token;

    }

    public String UsernameOlish(String auth){
        String subject = Jwts
                .parser()
                .setSigningKey(key)
                .parseClaimsJws(auth)
                .getBody()
                .getSubject();
        return subject;
    }
}
