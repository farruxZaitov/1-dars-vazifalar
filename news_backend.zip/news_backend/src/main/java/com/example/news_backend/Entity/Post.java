package com.example.news_backend.Entity;

import com.example.news_backend.Entity.Abstrak.AbstrakEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@EqualsAndHashCode(callSuper = true)
public class Post extends AbstrakEntity {

    @Column(nullable = false,columnDefinition = "text")
    private  String title;

    @Column(nullable = false, columnDefinition = "text")
    private String text;
}
