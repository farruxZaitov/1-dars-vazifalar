package com.example.news_backend.Payload;

import lombok.Data;

@Data
public class PostDto {
    private  String title;
    private String text;
}
