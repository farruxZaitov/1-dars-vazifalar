//package com.example.news_backend.Controller;
//
//import com.example.news_backend.Payload.ApiResponse;
//import com.example.news_backend.Payload.CommmentDto;
//import com.example.news_backend.Servise.CommentServis;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//@RequestMapping("/com")
//public class CommentController {
//    @Autowired
//    CommentServis commentServis;
//    @PostMapping("/qoshish")
//    public HttpEntity<?> Qoshish(@RequestBody CommmentDto commmentDto){
//        ApiResponse apiResponse=commentServis.qoshish(commmentDto);
//        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
//    }
//}
