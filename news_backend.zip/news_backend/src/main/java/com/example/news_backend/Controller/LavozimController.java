package com.example.news_backend.Controller;

import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.LavozimDto;
import com.example.news_backend.Servise.LavozimServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/lavozim")
public class LavozimController {
    @Autowired
    LavozimServise lavozimServise;

    @PostMapping("/addlavozim")
    public HttpEntity<?> LavozimQoshish(@Valid @RequestBody LavozimDto lavozimDto){
        ApiResponse apiResponse = lavozimServise.AddLavozim(lavozimDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @GetMapping("/korish")
    public HttpEntity<?> Korish(){
        ApiResponse apiResponse=lavozimServise.korish();
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @GetMapping("/{id}")
    public HttpEntity<?> Idboyicha(@PathVariable Integer id){
        ApiResponse apiResponse=lavozimServise.idboyicha(id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @PutMapping("/taxrilash/{id}")
    public HttpEntity<?> Taxrilash(@RequestBody LavozimDto lavozimDto,@PathVariable Integer id){
        ApiResponse apiResponse=lavozimServise.taxrilash(id,lavozimDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
    @DeleteMapping("/delet/{id}")
    public HttpEntity<?> Delet(@PathVariable Integer id){
        ApiResponse apiResponse=lavozimServise.delet(id);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getXabar());
    }
}
