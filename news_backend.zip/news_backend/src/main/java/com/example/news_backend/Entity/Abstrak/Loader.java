package com.example.news_backend.Entity.Abstrak;


import com.example.news_backend.Entity.Enum.Huquqlar;
import com.example.news_backend.Entity.Lavozim;
import com.example.news_backend.Entity.Users;
import com.example.news_backend.Repository.LavozimRepository;
import com.example.news_backend.Repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static com.example.news_backend.Entity.Enum.Huquqlar.*;

@Component
//@ComponentScan
public class Loader implements CommandLineRunner {
    @Autowired
    UsersRepository usersRepository;

    @Autowired
    LavozimRepository lavozimRepository;

    @Autowired
    PasswordEncoder passwordEncoder;
    @Value(value = "${spring.sql.init.mode}")
    private String holat;

    @Override
    public void run(String... args) throws Exception {
        if (holat.equals("always")){
            Huquqlar[] huquqlar = Huquqlar.values();

            //Admin huquqlari
            Lavozim admin = lavozimRepository.save(new Lavozim(
                    LavozimConstanta.ADMIN, Arrays.asList(huquqlar),
                    "admin"
            ));

            //User huquqlari
            Lavozim user = lavozimRepository.save(new Lavozim(
                    LavozimConstanta.USER,
                    Arrays.asList(
                            READ_COMMENT,
                            ADD_COMMENT,
                            EDIT_MY_COMMENT,
                            READ_POST,
                            DELETE_MY_COMMENT
                    ),
                    "user"
            ));



       /* LavozimConstanta.USER,
                Arrays.asList(
                        Huquqlar.READ_COMMENT,
                        Huquqlar.ADD_COMMENT,
                        Huquqlar.EDIT_MY_COMMENT,
                        Huquqlar.READ_POST,
                        Huquqlar.DELETE_MY_COMMENT
                )*/

            usersRepository.save(new Users(
                    "ADMIN",
                    "ADMINOV",
                    "998900085001",
                    "suhrobjonuz2022@gmail.com",
                    passwordEncoder.encode("123"),
                    admin,
                    true
            ));

            usersRepository.save(new Users(
                    "USER",
                    "USEROV",
                    "998971234567",
                    "wfegres@gmail.com",
                    passwordEncoder.encode("12345"),
                    user,
                    true
            ));
        }
    }
}
