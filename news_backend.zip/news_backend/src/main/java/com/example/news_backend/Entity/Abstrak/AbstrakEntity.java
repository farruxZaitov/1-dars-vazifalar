package com.example.news_backend.Entity.Abstrak;

import com.example.news_backend.Entity.Users;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import javax.persistence.*;
import java.sql.Timestamp;



@MappedSuperclass
@Data
public abstract class AbstrakEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    //@Column (nullable = false)
    @CreatedBy
    private  Integer kim_yaratdi;

    //@Column (nullable = false)
    @LastModifiedBy
    private Integer kim_tahrirladi;

    //@Column (nullable = false)
    @CreationTimestamp
    private Timestamp yaratilgan_vaqt;

    //@Column (nullable = false)
    @UpdateTimestamp
    private Timestamp tahrirlangan_vaqt;
}
