package com.example.news_backend.Payload;

import lombok.Data;

import javax.persistence.Column;

@Data
public class UsersDto {
    private String firsname;
    private  String lastname;
    private String number;
    private String username;
    private String password;
    private String repassword;

}
