package com.example.news_backend.Servise;

import com.example.news_backend.Entity.Lavozim;
import com.example.news_backend.Entity.Users;
import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.UserDuto1;
import com.example.news_backend.Repository.LavozimRepository;
import com.example.news_backend.Repository.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class User1_Servic {
    @Autowired
    UsersRepository usersRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    LavozimRepository lavozimRepository;
    public ApiResponse qoshish(UserDuto1 userDuto1) {
        boolean b = usersRepository.existsByUsername(userDuto1.getUsername());
        if (b){
            return new ApiResponse("Ma'lumotlar qaytadan kirting xatolik berdi",false);
        }
        if (userDuto1.getPassword().equals(userDuto1.getPassword())){
            Users users=new Users();
            users.setFirsname(userDuto1.getFirsname());
            users.setLastname(userDuto1.getLastname());
            users.setNumber(userDuto1.getNumber());
            users.setUsername(userDuto1.getUsername());
            users.setPassword(passwordEncoder.encode(userDuto1.getPassword()));
            Optional<Lavozim> byNomi = lavozimRepository.findByNomi(userDuto1.getLavozim());
            if (!byNomi.isPresent()){
                return new ApiResponse("Ma'lumot ishladi",false);
            }
            Lavozim lavozim = byNomi.get();
            users.setLavozim(lavozim);
            users.setEnabled(true);
            usersRepository.save(users);
            return new ApiResponse("Ma'lumot muvaqiyatli saqlandi",true);
        }

        return new ApiResponse("parol xato",false);
    }

    public ApiResponse korish() {
        List<Users> all = usersRepository.findAll();
        return new ApiResponse(all.toString(),true);
    }

    public ApiResponse idboyicha(Integer id) {
        Optional<Users> byId = usersRepository.findById(id);
        if (byId.isPresent()){
            return new ApiResponse(byId.get().toString(),true);
        }
        return new ApiResponse("Ma'lumot qaytadan ko'ring xatolik yuz berdi",false);
    }

    public ApiResponse taxrilash(UserDuto1 userDuto1, Integer id) {
        Optional<Users> byId = usersRepository.findById(id);
        if (byId.isPresent()){
            Users users=new Users();
            users.setFirsname(userDuto1.getFirsname());
            users.setLastname(userDuto1.getLastname());
            users.setNumber(userDuto1.getNumber());
            users.setUsername(userDuto1.getUsername());
            users.setPassword(passwordEncoder.encode(userDuto1.getPassword()));
            Optional<Lavozim> byNomi = lavozimRepository.findByNomi(userDuto1.getLavozim());
            Lavozim lavozim = byNomi.get();
            users.setLavozim(lavozim);
            users.setEnabled(true);
            usersRepository.save(users);
            return new ApiResponse("Ma'lumot taxrilandi",true);
        }
        return new ApiResponse("Ma'lmotni qaytadan kirting",false);
    }

    public ApiResponse delet(Integer id) {
        usersRepository.deleteById(id);
        return new ApiResponse("Ma'lumotingiz muvaqiyatli o'chirildi",true);
    }
}
