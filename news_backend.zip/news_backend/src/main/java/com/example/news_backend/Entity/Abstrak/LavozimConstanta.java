package com.example.news_backend.Entity.Abstrak;

public interface LavozimConstanta {
    String ADMIN = "admin";
    String  USER = "user";
}
