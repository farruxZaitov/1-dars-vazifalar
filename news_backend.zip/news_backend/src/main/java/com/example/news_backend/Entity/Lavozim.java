package com.example.news_backend.Entity;

import com.example.news_backend.Entity.Abstrak.AbstrakEntity;
import com.example.news_backend.Entity.Enum.Huquqlar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@EqualsAndHashCode(callSuper = true)

public class Lavozim extends AbstrakEntity {
    @NotBlank(message = "Lavozim nomida probel ishlatish mumkin emas")
    @Column(nullable = false)
    private String nomi;

    //@NotNull(message = "huquqlar listi bo'sh bo'lmasligi kerak !")
    @NotEmpty(message = "huquqlar listi bo'sh bo'lmasligi kerak !")
    @Enumerated(EnumType.ORDINAL)
    @ElementCollection(fetch = FetchType.LAZY)
    private List<Huquqlar> huquqlarList;

    @NotNull(message = "izoh bosh bolmasligi kerak")
    @Column(nullable = false)
    private String izoh;

}
