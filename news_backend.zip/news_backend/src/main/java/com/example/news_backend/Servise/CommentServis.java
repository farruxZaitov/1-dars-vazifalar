//package com.example.news_backend.Servise;
//
//import com.example.news_backend.Entity.Comment;
//import com.example.news_backend.Entity.Post;
//import com.example.news_backend.Payload.ApiResponse;
//import com.example.news_backend.Payload.CommmentDto;
//import com.example.news_backend.Repository.CommentRepository;
//import com.example.news_backend.Repository.PostRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.Optional;
//
//@Service
//public class CommentServis {
//    @Autowired
//    CommentRepository commentRepository;
//    @Autowired
//    PostRepository postRepository;
//    public ApiResponse qoshish(CommmentDto commmentDto) {
//        boolean b = commentRepository.existsByPostid(commmentDto.getPostid());
//        if (b) return new ApiResponse("Malumot yoq",false);
//        Comment comment=new Comment();
//        comment.setComment_text(commmentDto.getComment_text());
//        Optional<Post> byId = postRepository.findById(commmentDto.getPostid());
//        if (byId.isPresent()){
//            Post post = byId.get();
//            comment.setPost(byId.get());
//            commentRepository.save(comment);
//            return new ApiResponse("Malumot joylandi",true);
//        }
//        return new ApiResponse("joylamadi",false);
//    }
//}
