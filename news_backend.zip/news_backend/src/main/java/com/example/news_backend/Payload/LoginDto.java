package com.example.news_backend.Payload;

import lombok.Data;

@Data
public class LoginDto {
    private String username;
    private String password;
}
