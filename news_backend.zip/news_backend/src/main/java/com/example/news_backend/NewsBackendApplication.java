package com.example.news_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(NewsBackendApplication.class, args);
    }

}
