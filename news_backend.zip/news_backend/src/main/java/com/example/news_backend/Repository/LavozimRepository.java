package com.example.news_backend.Repository;

import com.example.news_backend.Entity.Lavozim;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LavozimRepository extends JpaRepository<Lavozim, Integer> {
    Optional<Lavozim>findByNomi(String nomi);

}

