package com.example.news_backend.Repository;

import com.example.news_backend.Entity.Post;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PostRepository extends JpaRepository<Post, Integer> {
      boolean existsByTitle(String title);

    Optional<Post> findById(Post postid);
}
