package com.example.news_backend.Servise;

import com.example.news_backend.Entity.Post;
import com.example.news_backend.Payload.ApiResponse;
import com.example.news_backend.Payload.PostDto;
import com.example.news_backend.Repository.PostRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class Post_Servis {
    @Autowired
    PostRepository postRepository;
    public ApiResponse qoshish(PostDto postDto) {
        boolean b = postRepository.existsByTitle(postDto.getTitle());
        if (b){
            return new ApiResponse("Ma'lumot qaytadan kirting",false);
        }
        Post post=new Post();
        post.setTitle(postDto.getTitle());
        post.setText(postDto.getText());
        postRepository.save(post);
        return new ApiResponse("Ma'lumot joylandi",true);
    }

    public ApiResponse korish() {
        List<Post> all = postRepository.findAll();
        return new ApiResponse(all.toString(),true);
    }

    public ApiResponse idboyicha(Integer id) {
        Optional<Post> byId = postRepository.findById(id);
        if (byId.isPresent()){
            return new ApiResponse(byId.get().toString(),true);
        }
        return new ApiResponse("Malumotni qaytadan kirting",false);
    }

    public ApiResponse taxrilash(Integer id, PostDto postDto) {
        Optional<Post> byId = postRepository.findById(id);
        if (byId.isPresent()){
            Post post = byId.get();
            post.setTitle(postDto.getTitle());
            post.setText(postDto.getText());
            postRepository.save(post);
            return new ApiResponse("Ma'lumot taxrilandi",true);
        }
        return new ApiResponse("Ma'lumotni qaytadan kirting",false);
    }
}
