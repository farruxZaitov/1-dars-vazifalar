package com.example.news_backend.Payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data

public class ApiResponse {
    private String xabar;
    private boolean holat;
}
