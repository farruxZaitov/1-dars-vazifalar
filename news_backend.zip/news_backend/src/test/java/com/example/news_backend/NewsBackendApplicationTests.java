package com.example.news_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
