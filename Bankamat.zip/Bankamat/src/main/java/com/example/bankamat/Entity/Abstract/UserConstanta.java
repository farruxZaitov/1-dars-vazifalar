package com.example.bankamat.Entity.Abstract;

public interface UserConstanta {

    String ADMIN="admin";
    String USER="user";
}
