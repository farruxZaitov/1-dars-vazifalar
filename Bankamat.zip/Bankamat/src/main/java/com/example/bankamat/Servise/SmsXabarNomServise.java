package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.SmsXabarNomaDto;
import com.example.bankamat.Repozitary.SmsXabarNomaRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SmsXabarNomServise {
    @Autowired
    SmsXabarNomaRepozitary smsXabarNomaRepozitary;

    public AypiRepons addSmsXabarJoylash(SmsXabarNomaDto smsXabarNomaDto) {

        return null;
    }
}
