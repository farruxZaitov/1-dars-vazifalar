package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class BankDto {
    private String nomi;
}
