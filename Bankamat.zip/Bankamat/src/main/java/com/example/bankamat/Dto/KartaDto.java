package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class KartaDto {
    private String login;
    private String parol4;
    private String kartaMudati;
    private Integer turiId;
    private Integer smsId;
    private double pulMiqdor;
    private String lavozim;
    private String kartaRaqami;
}
