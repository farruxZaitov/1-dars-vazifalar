package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.UserDto;
import com.example.bankamat.Entity.Users;
import com.example.bankamat.Repozitary.LavozimRepozitary;
import com.example.bankamat.Repozitary.ManzilRepozitary;
import com.example.bankamat.Repozitary.UserRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServise implements UserDetailsService {
    @Autowired
    UserRepozitary userRepozitary;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    ManzilRepozitary manzilRepozitary;
    @Autowired
    LavozimRepozitary lavozimRepozitary;

    public AypiRepons ADDUser(UserDto userDto){
        Optional<Users> byPasport = userRepozitary.findByPasport(userDto.getPasport());
        if (byPasport.isPresent()){
           return new AypiRepons("bunday user topilmadi",false);
        }
        Users users=new Users();
        users.setFish(userDto.getFish());
        users.setPasport(userDto.getPasport());
        users.setManzilId(manzilRepozitary.findById(userDto.getManzilId()).get());
        users.setLavozimId(lavozimRepozitary.findById(userDto.getLavozimId()).get());
        userRepozitary.save(users);
        return new AypiRepons("user joylandi",true);
    }

    @Override
    public UserDetails loadUserByUsername(String pasport) throws UsernameNotFoundException {
        Optional<Users> byPasport = userRepozitary.findByPasport(pasport);
        if (byPasport.isPresent()){
            return byPasport.get();
        }
        return (UserDetails) new UsernameNotFoundException("paspurt seriya  topilmadi");
    }



}
