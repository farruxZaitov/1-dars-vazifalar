package com.example.bankamat.Dto;

import com.example.bankamat.Entity.Enum.Xuquqlar;
import lombok.Data;

import javax.persistence.ElementCollection;
import javax.persistence.FetchType;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
public class LavozimDto {
    @NotBlank(message = "Problini olmaydi")
    private String nomi;
    @ElementCollection(fetch = FetchType.LAZY)
    @NotEmpty(message = "Huquqlar bo'sh bo'lmasloigi kk")
    private List<Xuquqlar> xuquqlarList;
    private String izoh;
}
