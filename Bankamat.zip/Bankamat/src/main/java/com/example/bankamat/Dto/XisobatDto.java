package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class XisobatDto {
    private String kirim;
    private String chiqim;
    private String qolganPul;
}
