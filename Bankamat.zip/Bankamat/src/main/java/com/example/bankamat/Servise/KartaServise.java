package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.KartaDto;
import com.example.bankamat.Entity.Karta;
import com.example.bankamat.Repozitary.KartaRepozitary;
import com.example.bankamat.Token.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class KartaServise  {
    @Autowired
    KartaRepozitary kartaRepozitary;

    public AypiRepons ADDkartaJoylash(KartaDto kartaDto) {
        Optional<Karta> byLogin = kartaRepozitary.findByLogin(kartaDto.getLogin());
        if(byLogin.isPresent()){
            return new AypiRepons("Karta qo'shilmadi",false);
        }
        Karta karta=new Karta();
        karta.setKartaMudati(kartaDto.getKartaMudati());
        karta.setLogin(kartaDto.getLogin());
        karta.setParol4(karta.getParol4());
        kartaRepozitary.save(karta);
        return new AypiRepons("Karta  qo'shildi",true);
    }



}
