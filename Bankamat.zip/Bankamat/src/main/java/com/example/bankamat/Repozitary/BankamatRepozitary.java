package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Bankamat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BankamatRepozitary extends JpaRepository<Bankamat,Integer> {

boolean existsByCardNumber(String cardNumber);
Optional<Bankamat> findByCardNumber(String cardNumber);

}
