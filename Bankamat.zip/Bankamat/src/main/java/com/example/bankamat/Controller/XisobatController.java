package com.example.bankamat.Controller;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.XisobatDto;
import com.example.bankamat.Servise.XisobatServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/XisobatJoylash")
public class XisobatController {
    @Autowired
    XisobatServise xisobatServise;
    @PostMapping("/ADDXisobatJoylash")
    public HttpEntity<?> ADDXisobatJoylash(@RequestBody XisobatDto xisobatDto){
        AypiRepons aypiRepons=xisobatServise.ADDXisobJoylash(xisobatDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }
}
