package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import com.example.bankamat.Entity.Enum.Xuquqlar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Users extends Abstrakt implements UserDetails  {
    @Column(nullable = false)
    private String fish;
    @Column(nullable = false)
    private String pasport;
    @OneToOne
    private Manzil  manzilId;
    @ManyToOne
    private Lavozim lavozimId;



    private boolean accountNonExpired = true;
    private boolean accountNonLocked = true;
    private boolean credentialsNonExpired = true;
    private boolean enabled = false;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {    // foydalanuvchini lovozimga xuquq;arni birlashtiradi
        List<Xuquqlar> xuquqlarList = this.lavozimId.getXuquqlarList();
        ArrayList<GrantedAuthority> grantedAuthorities=new ArrayList<>();
        for (Xuquqlar xuquqlar : xuquqlarList){
            grantedAuthorities.add(new GrantedAuthority() {
                @Override
                public String getAuthority() {return xuquqlar.name();}
            });
        }
        return grantedAuthorities;

    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    public Users(String fish, String pasport, Lavozim lavozimId, boolean enabled) {
        this.fish = fish;
        this.pasport = pasport;
        this.lavozimId = lavozimId;
        this.enabled = enabled;
    }
}
