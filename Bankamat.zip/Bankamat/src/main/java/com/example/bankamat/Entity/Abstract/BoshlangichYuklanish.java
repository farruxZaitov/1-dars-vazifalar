package com.example.bankamat.Entity.Abstract;

import com.example.bankamat.Entity.Enum.Xuquqlar;
import com.example.bankamat.Entity.Lavozim;
import com.example.bankamat.Entity.Users;
import com.example.bankamat.Repozitary.LavozimRepozitary;
import com.example.bankamat.Repozitary.UserRepozitary;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static com.example.bankamat.Entity.Enum.Xuquqlar.*;

@Data
@Component
public class BoshlangichYuklanish implements CommandLineRunner {
    @Value(value = "${spring.sql.init.mode}")
    String holatt;
    @Autowired
    UserRepozitary userRepozitary;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    LavozimRepozitary lavozimRepozitary;

    @Override
    public void run(String... args) throws Exception {
        if (holatt.equals("always")){
            Xuquqlar[] xuquqlars=Xuquqlar.values();
            Lavozim admin = lavozimRepozitary.save(new Lavozim(UserConstanta.ADMIN,Arrays.asList(xuquqlars)));

            Lavozim user = lavozimRepozitary.save(new Lavozim(
                    UserConstanta.USER, Arrays.asList(ADDUSER, REDUSER, EDITUSER, DALETEUSER)));

            userRepozitary.save(new Users(
                    "Admin","AB1234567",admin,true
            ));
            userRepozitary.save(new Users(
                    "farrux","BC1234567",user,true
            ));

        }
    }



}
