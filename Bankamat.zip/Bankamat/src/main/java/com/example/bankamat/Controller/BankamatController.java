package com.example.bankamat.Controller;

import com.example.bankamat.Dto.*;
import com.example.bankamat.Servise.BankamatServis;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/BankamatJoylash")
public class BankamatController {
    @Autowired
    BankamatServis bankamatServis;

    @PostMapping("/BankamatJoylash")
    public HttpEntity<?> BankamatJoylash(@RequestBody BankamatDto bankamatDto){
        AypiRepons aypiRepons=bankamatServis.ADDBankamatJoylas(bankamatDto);
        return  ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }
    @PutMapping("/pulYechish")
    public HttpEntity<?> pulyechish(@RequestBody BankamatDto bankamatDto,@PathVariable Integer id){
        AypiRepons aypiRepons=bankamatServis.pulYechish(id,bankamatDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }

    @PostMapping("/login")
    public HttpEntity<?> Login(@RequestBody LoginDto loginDto){
        AypiRepons apiResponse = bankamatServis.loginXodimga(loginDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getHabar());
    }
    @PostMapping("/hisobtoldir")
    public HttpEntity<?> toldir(@RequestBody PulDto pulDto){
        AypiRepons apiResponse=bankamatServis.toldir(pulDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getHabar());
    }
    @PutMapping("/parol")
    public HttpEntity<?> parol(@RequestBody ParolDto parolDto){
        AypiRepons apiResponse=bankamatServis.parol(parolDto);
        return ResponseEntity.status(apiResponse.isHolat()?200:208).body(apiResponse.getHabar());
    }


}
