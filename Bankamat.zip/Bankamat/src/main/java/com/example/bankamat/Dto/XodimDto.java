package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class XodimDto {
    private  String fish;
    private String username;
    private String password;
    private String lavozimId;
    private String emailKod;

}
