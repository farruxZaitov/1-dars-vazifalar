package com.example.bankamat.Controller;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.BankDto;
import com.example.bankamat.Servise.BankServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/BankJoylash")
public class BankController {
    @Autowired
    BankServise bankServise;
    @PostMapping("/ADD")
    public HttpEntity<?> BankJoylash(@RequestBody BankDto bankDto){
        AypiRepons aypiRepons=bankServise.ADDBankJoylash(bankDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }
}
