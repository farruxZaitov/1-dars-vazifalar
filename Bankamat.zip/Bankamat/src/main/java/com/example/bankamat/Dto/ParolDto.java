package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class ParolDto {
    private String newparol;
    private String reparol;
}
