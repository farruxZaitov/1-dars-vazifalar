package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.LavozimDto;
import com.example.bankamat.Entity.Lavozim;
import com.example.bankamat.Repozitary.LavozimRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class LavozimServise {
    @Autowired
    LavozimRepozitary lavozimRepozitary;


    public AypiRepons ADDLavzim(LavozimDto lavozimDto) {
        Optional<Lavozim> byNomi = lavozimRepozitary.findByNomi(lavozimDto.getNomi());
        if (byNomi.isPresent()){
            return new AypiRepons("Joylmadi",false);
        }
        Lavozim lavozim=new Lavozim();
        lavozim.setNomi(lavozimDto.getNomi());
        lavozim.setXuquqlarList(lavozimDto.getXuquqlarList());
        lavozimRepozitary.save(lavozim);
        return new AypiRepons("Lavozim qo'shildi",true);
    }
}
