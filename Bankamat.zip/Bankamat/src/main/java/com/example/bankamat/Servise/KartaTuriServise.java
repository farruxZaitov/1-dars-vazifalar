package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.KartaTuriDto;
import com.example.bankamat.Entity.KartaTuri;
import com.example.bankamat.Repozitary.KartaTuriRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class KartaTuriServise {
    @Autowired
    KartaTuriRepozitary kartaTuriRepozitary;

    public AypiRepons KartaTuriJoylash(KartaTuriDto kartaTuriDto) {
        Optional<KartaTuri> byNomi = kartaTuriRepozitary.findByNomi(kartaTuriDto.getNomi());
        if (byNomi.isPresent()){
            return new AypiRepons("Joylmadi",false);
        }
        KartaTuri kartaTuri=new KartaTuri();
        kartaTuri.setNomi(kartaTuri.getNomi());
        kartaTuriRepozitary.save(kartaTuri);
        return new AypiRepons("Karta turi qo'shildi",true);

    }
}
