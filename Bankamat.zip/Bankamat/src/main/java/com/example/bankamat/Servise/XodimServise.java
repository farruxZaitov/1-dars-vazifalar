package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.XodimDto;
import com.example.bankamat.Entity.Xodim;
import com.example.bankamat.Repozitary.XodimRepozitary;
import com.example.bankamat.Token.Token;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class XodimServise {
    @Autowired
    XodimRepozitary xodimRepozitary;
    @Autowired
    Token token;
    @Autowired
    AuthenticationManager authenticationManager;
    public AypiRepons ADDXodimJoylash(XodimDto xodimDto) {
        Optional<Xodim> byUsername = xodimRepozitary.findByUsername(xodimDto.getUsername());
        if (byUsername.isPresent()){
            Xodim xodim=new Xodim();
            xodim.setFish(xodimDto.getFish());
            xodim.setUsername(xodimDto.getUsername());
            xodim.setPassword(xodim.getPassword());
            xodim.setLavozimId(xodim.getLavozimId());
            xodimRepozitary.save(xodim);
            return new AypiRepons("Xodim qo'shildi",true);
        }
        return null;
    }



}
