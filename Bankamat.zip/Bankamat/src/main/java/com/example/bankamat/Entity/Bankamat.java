package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@EntityListeners(AuditingEntityListener.class)
public class Bankamat extends Abstrakt implements UserDetails {

    @Column(nullable = false)
    private double yechMaxPul;
    @Column(nullable = false)
    private double yechMinPul;
    @Column(nullable = false)
    private double pulMiqdori;
    @Column(nullable = false)
    private double yechiladiganPul;

    @Column(nullable = false)
    private String bankNomi;
    @OneToOne
    private Manzil manzilId;
    @OneToOne
    private Xisobat xisobatId;

    private String cardNumber;

    @Column(nullable = false)
    private String password;

    private long money;
    private double OpshiPul;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }




}
