package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import java.util.Collection;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Xodim extends Abstrakt{

    @Column(nullable = false)
    private  String fish;
    @Column(nullable = false)
    private String username;
    @Column(nullable = false)
    private String password;

    private String emailKod;


    @OneToOne
    private Lavozim lavozimId;
    private boolean accountNonExpired=true;
    private boolean accountNonLocked=true;
    private boolean credentialsNonExpired=true;
    private boolean enabled=false;
    }
