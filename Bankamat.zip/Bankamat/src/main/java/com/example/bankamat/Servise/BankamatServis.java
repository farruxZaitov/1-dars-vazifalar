package com.example.bankamat.Servise;

import com.example.bankamat.Dto.*;
import com.example.bankamat.Entity.*;
import com.example.bankamat.Repozitary.*;
import com.example.bankamat.Token.Token;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BankamatServis implements UserDetailsService {
    @Autowired
    BankamatRepozitary bankamatRepozitary;
    @Autowired
    KartaRepozitary kartaRepozitary;

    @Autowired
    JavaMailSender javaMailSender;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    PasswordEncoder passwordEncoder;


    @Autowired
    Token token;

    @Autowired
    XodimRepozitary xodimRepozitary;

    @Autowired
    LavozimRepozitary lavozimRepozitary;

    @Autowired
    UserRepozitary userRepozitary;
    @Autowired
    JavaMailSender getJavaMailSender;

    @Autowired
    KamsiyaRepozitary kamsiyaRepozitary;

    @Autowired
    KartaTuriRepozitary kartaTuriRepozitary;


    public AypiRepons ADDBankamatJoylas(BankamatDto bankamatDto) {
        Bankamat bankamat=new Bankamat();
        bankamat.setYechMaxPul(bankamatDto.getYechMaxPul());
        bankamat.setYechMinPul(bankamatDto.getYechMinPul());
        bankamat.setPulMiqdori(bankamat.getPulMiqdori());
        bankamatRepozitary.save(bankamat);
        return  new AypiRepons("Bankamat joylandi",true);
    }

    public AypiRepons pulYechish(Integer id, BankamatDto bankamatDto) {
        Optional<Bankamat> byId = bankamatRepozitary.findById(id);
        if (byId.isPresent()){
            Optional<Karta> byLogin = kartaRepozitary.findByLogin(bankamatDto.getLogin());
            if (byLogin.isPresent()){
                Bankamat bankamat = byId.get();
                Karta karta = byLogin.get();
                if (bankamatDto.getYechMinPul()>karta.getPulMiqdor()){
                    return new AypiRepons("Kartangizda pul yetarli emas",false);
                }
                if (bankamatDto.getPulMiqdori()<karta.getPulMiqdor() || bankamat.getPulMiqdori()>karta.getPulMiqdor()){
                    bankamat.setPulMiqdori(bankamat.getPulMiqdori()-bankamatDto.getYechiladiganPul());
                    bankamatRepozitary.save(bankamat);
                    karta.setPulMiqdor(karta.getPulMiqdor()-bankamatDto.getYechiladiganPul());
                    kartaRepozitary.save(karta);
                    if (bankamat.getPulMiqdori()<10000000){
                        XabarYuborish("farruxzaitov7176@gmail.com","farrux2003");
                    }
                    return new AypiRepons("saqlandi",true);
                }
                return new AypiRepons("pul yechilmadi",false);
            }
            return new AypiRepons("Kartada pul mavjud emas",false);
        }
        return new AypiRepons("Bankamatda pul yoq",false);
    }

    public boolean XabarYuborish(String email,String emailkod){
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setFrom("farruxzaitov7176@gmail.com");
            mailMessage.setTo(email);
            mailMessage.setSubject("Confirmation email");
            mailMessage.setText("<a href='http://localhost:8080/auth/emailtasdiqlash?useremail="+email+"&emailkod="+emailkod+" '>hisobni tasdiqlash</a>");

            getJavaMailSender.send(mailMessage);
            return true;
        }
        catch (Exception e){
            e.getStackTrace();
        }
        return false;
    }

    public AypiRepons loginXodimga(LoginDto loginDto) {
        try {
            Authentication authenticate = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginDto.getUsername(), loginDto.getPassword()));
            Karta principal = (Karta) authenticate.getPrincipal();
            String s = token.CreateToken(principal.getUsername(), principal.getLavozim());
            return new AypiRepons("profilga xush kelibsiz!" + s,true);
        }
        catch (Exception e) {
            return new AypiRepons("login yoki parol xato", false);
        }
    }

    public AypiRepons toldir(PulDto pulDto) {
        try {
            Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
            Karta karta=(Karta)authentication.getPrincipal();
            Optional<Kamsiya> byBank = kamsiyaRepozitary.findByBank(karta.getBank());
            Kamsiya kamsiya = byBank.get();
            long sum=karta.getPull();
            sum+=(pulDto.getSumma())*(kamsiya.getKamsiyaTuldirish());
            Optional<Bankamat> byId = bankamatRepozitary.findById(karta.getId());
            Bankamat bankamat = byId.get();
            karta.setPull(sum);
            bankamatRepozitary.save(bankamat);
            Optional<Bankamat> byId1 = bankamatRepozitary.findById(1);
            Bankamat bankamat1 = byId1.get();
            double bankamatpuli=bankamat1.getOpshiPul()+pulDto.getSumma();
            bankamat1.setOpshiPul(bankamatpuli);

            bankamatRepozitary.save(bankamat1);
            return new AypiRepons("Pul o'tkazildi",true);
        }catch (BadCredentialsException badCredentialsException){
            return new AypiRepons("Login yoki parol xato",false);
        }
    }

    public AypiRepons parol(ParolDto parolDto) {
        try {
            Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
            Karta karta = (Karta) authentication.getPrincipal();
            if (!parolDto.getNewparol().equals(parolDto.getReparol())){
                return new AypiRepons("parollar mos emas",false);
            }
            Optional<Bankamat> byId = bankamatRepozitary.findById(karta.getId());
            if (byId.isPresent()){
                Bankamat bankamat = byId.get();
                bankamat.setPassword(passwordEncoder.encode(parolDto.getNewparol()));
                bankamatRepozitary.save(bankamat);
                return new AypiRepons("Parol "+parolDto.getNewparol()+" ga o'zgardi.",true);
            }
            return new AypiRepons("Xato",false);
        }
        catch (BadCredentialsException badCredentialsException){
            return new AypiRepons("Login yoki parol xato",false);
        }

    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<Xodim> byUsername = xodimRepozitary.findByUsername(username);
        if(byUsername.isPresent()){
            return (UserDetails) byUsername.get();
        }
        Optional<Karta> byCardNumber = kartaRepozitary.findByLogin(username);
        if(byCardNumber.isPresent()){
            return (UserDetails) byCardNumber.get();
        }
        return (UserDetails) new UsernameNotFoundException("Topilmadi");
    }
}
