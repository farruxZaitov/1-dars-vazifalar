package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepozitary extends JpaRepository<Users, Integer> {
    Optional<Users> findByPasport(String pasport);
}
