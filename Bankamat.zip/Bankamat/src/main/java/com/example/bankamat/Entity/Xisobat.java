package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.Entity;
import java.util.Collection;


@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Xisobat extends Abstrakt{
    private String kirim;
    private String chiqim;
    private String qolganPul;


}
