package com.example.bankamat.Controller;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.LavozimDto;
import com.example.bankamat.Servise.LavozimServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/LavozimJoylash")
public class LavozimController {
    @Autowired
    LavozimServise lavozimServise;
    @PostMapping("/ADDLavozim")
    public HttpEntity<?> ADDLavozim( @RequestBody LavozimDto lavozimDto){
        AypiRepons aypiRepons=lavozimServise.ADDLavzim(lavozimDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }
}
