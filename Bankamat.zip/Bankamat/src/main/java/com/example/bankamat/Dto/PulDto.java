package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class PulDto {
    private double summa;
}
