package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Collection;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Bank extends Abstrakt {

    @Column(nullable = false)
    private String nomi;

    @Column(nullable = false)
    private String bankNomi;


}
