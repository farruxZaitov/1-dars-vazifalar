package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class BankamatDto {
    private double yechMaxPul;
    private double yechMinPul;
    private double pulMiqdori;
    private String Login;
    private double yechiladiganPul;
    private String kartaRaqami;

}
