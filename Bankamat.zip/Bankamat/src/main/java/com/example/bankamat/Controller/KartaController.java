package com.example.bankamat.Controller;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.KartaDto;
import com.example.bankamat.Servise.KartaServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/KartaJoylash")
public class KartaController {
    @Autowired
    KartaServise kartaServise;
    @PostMapping("/KartaJoylash")
    public HttpEntity<?> ADDkartaJoylash(@RequestBody KartaDto kartaDto){
        AypiRepons aypiRepons=kartaServise.ADDkartaJoylash(kartaDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }


}
