package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.XisobatDto;
import com.example.bankamat.Entity.Xisobat;
import com.example.bankamat.Repozitary.XisobatRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class XisobatServise {
    @Autowired
    XisobatRepozitary xisobatRepozitary;

    public AypiRepons ADDXisobJoylash(XisobatDto xisobatDto) {
        Optional<Xisobat> byQolganPul = xisobatRepozitary.findByQolganPul(xisobatDto.getQolganPul());
        if (byQolganPul.isPresent()){
            Xisobat xisobat=new Xisobat();
            xisobat.setKirim(xisobatDto.getKirim());
            xisobat.setChiqim(xisobatDto.getChiqim());
            xisobat.setQolganPul(xisobatDto.getQolganPul());
            xisobatRepozitary.save(xisobat);
            return new AypiRepons("Xisobat yetqazildi",true);
        }
        return null;
    }
}
