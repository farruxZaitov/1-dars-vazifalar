package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Xisobat;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface XisobatRepozitary extends JpaRepository<Xisobat,Integer> {
    Optional<Xisobat> findByQolganPul(String qolganPul);
}
