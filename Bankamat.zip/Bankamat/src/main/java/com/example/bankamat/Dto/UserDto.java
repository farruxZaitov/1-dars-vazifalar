package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class UserDto {

    private String fish;
    private String pasport;
    private Integer lavozimId;
    private Integer manzilId;
}
