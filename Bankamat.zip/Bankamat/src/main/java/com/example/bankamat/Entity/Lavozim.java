package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import com.example.bankamat.Entity.Enum.Xuquqlar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.*;
import java.util.Collection;
import java.util.List;


@NoArgsConstructor
@Data
@Entity
public class Lavozim extends Abstrakt {
    @Column(nullable = false)
    private String nomi;
    @Enumerated(EnumType.STRING)
    @ElementCollection(fetch = FetchType.LAZY)
    private List<Xuquqlar> xuquqlarList;

    public Lavozim(String nomi, List<Xuquqlar> xuquqlarList) {
        this.nomi = nomi;
        this.xuquqlarList = xuquqlarList;
    }

}
