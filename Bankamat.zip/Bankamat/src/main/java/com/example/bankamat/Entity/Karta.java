package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.persistence.*;
import java.util.Collection;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Karta extends Abstrakt implements UserDetails {

    @Column(nullable = false)
    private String login;
    @Column(nullable = false)
    private String parol4;
    @Column(nullable = false)
    private String kartaMudati;
    @Column(nullable = false)
    private double pulMiqdor;

    @Column(nullable = false)
    private String kartaNomi;
    @ManyToOne
    private Lavozim lavozim;
    @ManyToOne
    private KartaTuri kartaTuri;

    private String cardNumber;
    private long pull;
    @Column(nullable = false)
    private String bankNomi;
    @ManyToOne
    private Bank bank;

    @OneToOne
    private KartaTuri kartaId;
    @OneToOne
    private Users usersId;
    @OneToOne
    private SmsXabarNoma smsXabarNomaId;


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }

    @Override
    public String getPassword() {
        return null;
    }

    @Override
    public String getUsername() {
        return null;
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }



}
