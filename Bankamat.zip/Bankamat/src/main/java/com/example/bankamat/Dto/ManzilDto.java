package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class ManzilDto {
    private String viloyat;
    private String tuman;
    private String kocha;

}
