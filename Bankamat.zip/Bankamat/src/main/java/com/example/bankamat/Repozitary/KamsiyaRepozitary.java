package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Bank;
import com.example.bankamat.Entity.Kamsiya;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface KamsiyaRepozitary extends JpaRepository<Kamsiya,Integer> {


   Optional<Kamsiya> findByBank(Bank bank);
}