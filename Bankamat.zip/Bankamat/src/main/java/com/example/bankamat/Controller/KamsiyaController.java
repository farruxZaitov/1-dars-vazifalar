package com.example.bankamat.Controller;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.KamsiyDto;
import com.example.bankamat.Dto.KartaDto;
import com.example.bankamat.Dto.ManzilDto;
import com.example.bankamat.Servise.KamsiyaServise;
import com.example.bankamat.Servise.ManzilServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/KamsiyaJoylash")
public class KamsiyaController {
    @Autowired
    KamsiyaServise kamsiyaServise;
    @PreAuthorize(value = "hasAuthority('ADDKamisiya')")
    @PostMapping("/KamsiyaJoylash")
    public HttpEntity<?> ManzilJoylash(@RequestBody KamsiyDto kamsiyDto){
      AypiRepons aypiRepons=kamsiyaServise.ADDKamsiyaJoylash(kamsiyDto);
        return ResponseEntity.status(aypiRepons.isHolat()?200:208).body(aypiRepons.getHabar());
    }
}
