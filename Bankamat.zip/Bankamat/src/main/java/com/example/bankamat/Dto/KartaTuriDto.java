package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class KartaTuriDto {
 private String nomi;
}
