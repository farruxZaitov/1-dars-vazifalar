package com.example.bankamat.Token;


import com.example.bankamat.Servise.KartaServise;
import com.example.bankamat.Servise.UserServise;
import com.example.bankamat.Servise.XodimServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class Filtr extends OncePerRequestFilter {
    @Autowired
    Token token;

    @Autowired
    KartaServise kartaServise;
    @Autowired
    UserServise userServise;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        String authentication = request.getHeader("Auth");
            if (token.tokenCheck(authentication)){
                System.out.println(authentication);
                String s = token.UsernameOlish(authentication);
                UserDetails userDetails = userServise.loadUserByUsername(s);
                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails, null,userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
            }
            else System.out.println("null");

        filterChain.doFilter(request, response);
    }
}
