package com.example.bankamat.Entity;

import com.example.bankamat.Entity.Abstract.Abstrakt;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import java.util.Collection;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Kamsiya extends Abstrakt {

    @Column(nullable = false)
    public double kamisiyaYechish;
    @Column(nullable = false)
    public double kamsiyaTuldirish;
    @OneToOne
    private Bank bank;


}
