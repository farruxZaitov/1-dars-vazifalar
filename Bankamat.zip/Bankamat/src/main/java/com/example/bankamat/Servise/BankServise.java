package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.BankDto;
import com.example.bankamat.Dto.BankamatDto;
import com.example.bankamat.Entity.Bank;
import com.example.bankamat.Repozitary.BankRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class BankServise {
    @Autowired
    BankRepozitary bankRepozitary;
    public AypiRepons ADDBankJoylash(BankDto bankDto) {
        Optional<Bank> byNomi = bankRepozitary.findByNomi(bankDto.getNomi());

        if (byNomi.isPresent()){
            return new AypiRepons("Joylmadi",false);
        }
        Bank bank=new Bank();
        bank.setNomi(bankDto.getNomi());
        bankRepozitary.save(bank);
        return new AypiRepons("Bank  qo'shildi",true);
    }


}
