package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class SmsXabarNomaDto {
    private String telNomer;
    private String yechilganPulMiqdor;
    private String qolganPulMiqdor;
    private String userId;
    private String sana;

}
