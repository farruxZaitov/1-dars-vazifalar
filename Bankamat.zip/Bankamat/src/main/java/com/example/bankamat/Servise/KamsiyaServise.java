package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.KamsiyDto;
import com.example.bankamat.Dto.KartaDto;
import com.example.bankamat.Entity.Bank;
import com.example.bankamat.Entity.Bankamat;
import com.example.bankamat.Entity.Kamsiya;
import com.example.bankamat.Repozitary.BankRepozitary;
import com.example.bankamat.Repozitary.BankamatRepozitary;
import com.example.bankamat.Repozitary.KamsiyaRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class KamsiyaServise {
    @Autowired
    KamsiyaRepozitary kamsiyaRepozitary;

    @Autowired
    BankRepozitary bankRepozitary;


    public AypiRepons ADDKamsiyaJoylash(KamsiyDto kamsiyDto) {
        Optional<Bank> byNomi = bankRepozitary.findByNomi(kamsiyDto.getBanknomi());

        if (byNomi.isPresent()){
            Kamsiya kamsiya=new Kamsiya();
            kamsiya.setKamsiyaTuldirish(kamsiyDto.getKomissiyatoldirish());
            kamsiya.setKamisiyaYechish(kamsiyDto.getKomissiyayechish());
            //kamsiya.setBank(b.get());

            kamsiyaRepozitary.save(kamsiya);
            return new AypiRepons("Komissiya qo'shildi",true);
        }
        return new AypiRepons("Bank mavjud emas",false);
    }
}
