package com.example.bankamat.Servise;

import com.example.bankamat.Dto.AypiRepons;
import com.example.bankamat.Dto.ManzilDto;
import com.example.bankamat.Entity.Manzil;
import com.example.bankamat.Repozitary.ManzilRepozitary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ManzilServise {
    @Autowired
    ManzilRepozitary manzilRepozitary;

    public AypiRepons ADDmanzilJoylash(ManzilDto manzilDto) {
        Optional<Manzil> byManzilId = manzilRepozitary.findByManzilId(manzilDto.getViloyat());
        if (byManzilId.isPresent()){
            return new AypiRepons("Manzil joylanmadi",false);
        }
        Manzil manzil=new Manzil();
        manzil.setManzilId(manzilDto.getViloyat());
        manzil.setManzilId(manzilDto.getTuman());
        manzil.setManzilId(manzilDto.getKocha());
        manzilRepozitary.save(manzil);
        return new AypiRepons("Manzil Joylandi",true);
    }

    public AypiRepons ADDManzilJoylash(ManzilDto manzilDto) {
        Optional<Manzil> byManzilId = manzilRepozitary.findByManzilId(manzilDto.getViloyat());
        if (byManzilId.isPresent()){
            return  new AypiRepons("Manzil Joylanmadi",false);
        }
        Manzil manzil=new Manzil();
        manzil.setManzilId(manzilDto.getViloyat());

        return null;
    }
}
