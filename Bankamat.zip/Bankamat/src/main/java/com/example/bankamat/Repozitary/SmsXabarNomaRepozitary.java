package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.SmsXabarNoma;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SmsXabarNomaRepozitary extends JpaRepository<SmsXabarNoma,Integer> {

}
