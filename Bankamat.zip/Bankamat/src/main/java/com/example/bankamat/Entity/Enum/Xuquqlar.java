package com.example.bankamat.Entity.Enum;

public enum Xuquqlar {
    ADDUSER,
    DALETEUSER,
    EDITUSER,
    REDUSER,        //Foydalanuvchilar user uqish

    ADDKamisiya,
    DALETEKamisiya,
    EDITKamisiya,
    REDKamisiya,

    ADDBULIM,
    READBULIM,
    DELETEBULIM,
    EDITBULIM,

    ADDLOVOZIM,
    RIDLOVOZIM,
    DELETELAVOZIM,
    EDITLOVOZIM
}
