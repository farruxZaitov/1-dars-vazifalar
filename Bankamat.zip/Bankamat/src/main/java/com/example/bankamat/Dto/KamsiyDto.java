package com.example.bankamat.Dto;

import lombok.Data;

@Data
public class KamsiyDto {
    public double komissiyayechish;
    public double komissiyatoldirish;
    public String  banknomi;
}
