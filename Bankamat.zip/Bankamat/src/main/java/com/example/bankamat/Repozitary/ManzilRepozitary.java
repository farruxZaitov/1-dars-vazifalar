package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Manzil;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ManzilRepozitary extends JpaRepository<Manzil,Integer> {
    Optional<Manzil> findByManzilId(String manzilId);
}
