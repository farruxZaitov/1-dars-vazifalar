package com.example.bankamat.Repozitary;

import com.example.bankamat.Entity.Bank;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BankRepozitary extends JpaRepository<Bank,Integer> {
  //  boolean existsByNomi(String nomi);
    Optional<Bank> findByNomi(String nomi);


}
