package com.example.bankamat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankamatApplicationTests {

    @Test
    void contextLoads() {
    }

}
